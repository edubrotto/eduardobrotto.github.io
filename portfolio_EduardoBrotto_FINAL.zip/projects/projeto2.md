# Projeto 2 — Assistente Virtual para Atendimento

**Descrição:**  
Assistente virtual baseado em IA com respostas automáticas e análise de sentimentos.

**Tecnologias:**  
Python, NLP, TensorFlow
