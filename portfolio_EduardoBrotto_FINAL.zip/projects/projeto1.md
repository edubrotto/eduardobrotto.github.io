# Projeto 1 — Sistema de Automação para Pequenas Empresas

**Descrição:**  
Sistema criado para automatizar tarefas do dia a dia de pequenas empresas, como envio automático de e-mails e automação de estoque.

**Tecnologias:**  
Python, Zapier, Google Sheets API
