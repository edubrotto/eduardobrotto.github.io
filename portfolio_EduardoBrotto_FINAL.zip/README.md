# Portfólio — Eduardo Brotto

Este é o portfólio oficial desenvolvido como parte do PortfolioHUB.

## Como publicar no GitHub Pages
1. Crie o repositório `eduardobrotto.github.io`
2. Faça upload dos arquivos
3. Vá em Settings → Pages → Branch: main → Save
4. Acesse: https://eduardobrotto.github.io
